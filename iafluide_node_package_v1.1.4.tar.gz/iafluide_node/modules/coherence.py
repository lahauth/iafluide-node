# Module coherence

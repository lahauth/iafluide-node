# Module propagation

#!/bin/bash
source venv/bin/activate
nohup python3 app.py > flask.log 2>&1 &
nohup python3 -m http.server 8005 --directory static > http.log 2>&1 &

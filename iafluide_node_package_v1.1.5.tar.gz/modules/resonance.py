# Module resonance

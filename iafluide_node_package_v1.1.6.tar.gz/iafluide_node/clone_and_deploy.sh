#!/bin/bash
echo 'Déploiement IA Fluide...'